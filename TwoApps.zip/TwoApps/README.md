# Two Apps

Opens two apps together on your Android phone:

- **Open floating**: first app fills the screen, second app opens in a small floating window on top.
- **Open split screen**: first app on top, second app below.

## Build it (on a computer)

1. Install Android Studio (free): https://developer.android.com/studio
2. Open Android Studio > Open > choose the `TwoApps` folder. Wait for "Gradle sync" to finish (it downloads what it needs).
3. On your phone: Settings > About phone > tap "Build number" 7 times. Then Settings > System > Developer options > turn on **USB debugging**.
4. Plug the phone into the computer with a USB cable and allow the debugging prompt on the phone.
5. In Android Studio, pick your phone at the top and press the green Run button. The app installs on your phone.

## Set up the phone

**For floating windows** (Developer options):
- Turn on **Enable freeform windows**
- Turn on **Force activities to be resizable**
- Restart the phone

**For split screen**:
- Open Two Apps, tap **Open split screen**, then **Open settings**
- Find **Two Apps** in the Accessibility list and turn it on
- Come back and tap **Open split screen** again

## Notes

- Some apps (banking apps, some games) refuse to be resized or floated.
- If the second app doesn't land in the other half of split screen, tap it in the recent-apps list that appears there.
- This was written without being able to run it on a real phone, so tell me what happens and I'll fix it.
