package com.example.twoapps

import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

data class AppEntry(val label: String, val pkg: String, val icon: Drawable)

class MainActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("twoapps", MODE_PRIVATE) }
    private val apps: List<AppEntry> by lazy { loadApps() }

    private var pkgA: String? = null
    private var pkgB: String? = null

    private lateinit var pickA: Button
    private lateinit var pickB: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        pkgA = prefs.getString("pkgA", null)
        pkgB = prefs.getString("pkgB", null)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }

        root.addView(TextView(this).apply {
            text = "Two Apps"
            textSize = 28f
            setPadding(0, 0, 0, dp(8))
        })
        root.addView(TextView(this).apply {
            text = "Pick two apps, then open them together."
            textSize = 15f
            setPadding(0, 0, 0, dp(24))
        })

        pickA = Button(this).apply {
            setOnClickListener {
                choose("First app (fills the screen)") {
                    pkgA = it.pkg
                    prefs.edit().putString("pkgA", it.pkg).apply()
                    refresh()
                }
            }
        }
        pickB = Button(this).apply {
            setOnClickListener {
                choose("Second app (floats on top)") {
                    pkgB = it.pkg
                    prefs.edit().putString("pkgB", it.pkg).apply()
                    refresh()
                }
            }
        }
        root.addView(pickA, matchWidth())
        root.addView(pickB, matchWidth())

        root.addView(Button(this).apply {
            text = "Open floating"
            setOnClickListener { launchFloating() }
        }, matchWidth().apply { topMargin = dp(24) })

        root.addView(Button(this).apply {
            text = "Open split screen"
            setOnClickListener { launchSplit() }
        }, matchWidth())

        root.addView(TextView(this).apply {
            text = "Floating needs \"Enable freeform windows\" and \"Force activities to be " +
                "resizable\" turned on in Developer options (then restart the phone). " +
                "Some apps refuse to float.\n\n" +
                "Split screen needs this app turned on once in Accessibility settings."
            textSize = 13f
            gravity = Gravity.START
            setPadding(0, dp(24), 0, 0)
        })

        setContentView(root)
        refresh()
    }

    private fun refresh() {
        pickA.text = "First app: " + (labelFor(pkgA) ?: "tap to choose")
        pickB.text = "Second app: " + (labelFor(pkgB) ?: "tap to choose")
    }

    private fun labelFor(pkg: String?): String? = apps.firstOrNull { it.pkg == pkg }?.label

    private fun loadApps(): List<AppEntry> {
        val pm = packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(query, 0)
            .map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    private fun choose(title: String, onPick: (AppEntry) -> Unit) {
        val adapter = object : ArrayAdapter<AppEntry>(this, 0, apps) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val row = (convertView as? LinearLayout) ?: LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(16), dp(8), dp(16), dp(8))
                    addView(ImageView(context), LinearLayout.LayoutParams(dp(40), dp(40)))
                    addView(TextView(context).apply {
                        textSize = 16f
                        setPadding(dp(16), 0, 0, 0)
                    })
                }
                val item = getItem(position)!!
                (row.getChildAt(0) as ImageView).setImageDrawable(item.icon)
                (row.getChildAt(1) as TextView).text = item.label
                return row
            }
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setAdapter(adapter) { _, index -> onPick(apps[index]) }
            .show()
    }

    private fun launchIntentFor(pkg: String?): Intent? {
        if (pkg == null) {
            Toast.makeText(this, "Choose both apps first", Toast.LENGTH_SHORT).show()
            return null
        }
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) {
            Toast.makeText(this, "Can't open that app", Toast.LENGTH_SHORT).show()
        }
        return intent
    }

    private fun launchFloating() {
        val first = launchIntentFor(pkgA) ?: return
        val second = launchIntentFor(pkgB) ?: return

        val dm = resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels
        val bounds = Rect((w * 0.04).toInt(), (h * 0.40).toInt(), (w * 0.96).toInt(), (h * 0.88).toInt())

        try {
            startActivity(first)

            val options = ActivityOptions.makeBasic()
            options.setLaunchBounds(bounds)
            try {
                // 5 = freeform windowing mode. Hidden on many phones; harmless if it fails.
                ActivityOptions::class.java
                    .getMethod("setLaunchWindowingMode", Int::class.javaPrimitiveType)
                    .invoke(options, 5)
            } catch (_: Throwable) {
            }
            startActivity(second, options.toBundle())
        } catch (e: Exception) {
            Toast.makeText(this, "Couldn't open the apps: " + e.message, Toast.LENGTH_LONG).show()
        }
    }

    private fun launchSplit() {
        val first = launchIntentFor(pkgA) ?: return
        val second = launchIntentFor(pkgB) ?: return

        if (!SplitService.isEnabled()) {
            AlertDialog.Builder(this)
                .setTitle("Turn on Two Apps")
                .setMessage(
                    "Open Accessibility settings, find \"Two Apps\" (it may be under " +
                        "Installed apps), and turn it on. Then come back and tap Open split screen."
                )
                .setPositiveButton("Open settings") { _, _ ->
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
                .setNegativeButton("Cancel", null)
                .show()
            return
        }

        startActivity(first)
        SplitService.splitWith(second)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun matchWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
