package com.example.twoapps

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/**
 * Presses the system "split screen" action, then tries to open the second app
 * next to the first one. It never reads what is on screen.
 */
class SplitService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    private fun splitWithSecond(second: Intent) {
        val handler = Handler(Looper.getMainLooper())

        // Give the first app a moment to come to the front, then split the screen.
        handler.postDelayed({
            performGlobalAction(GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN)
        }, 1200)

        // Try to put the second app in the other half. If the phone blocks this,
        // the empty half shows your recent apps and you can tap the second app.
        handler.postDelayed({
            try {
                second.addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT
                )
                startActivity(second)
            } catch (_: Throwable) {
                // Ignored on purpose: see comment above.
            }
        }, 2400)
    }

    companion object {
        @Volatile
        private var instance: SplitService? = null

        fun isEnabled(): Boolean = instance != null

        fun splitWith(second: Intent) {
            instance?.splitWithSecond(second)
        }
    }
}
